/**
 * Created by avery on 3/6/15.
 */

//begin Java code
// variable for numerical value
var yearSchool = " 2015";
// Variable for string
var statementSchool = "I began going to: ";
// Variable for string
var whichSchool = "Full Sail in ";

// assigning yearSchool value to y
var y = yearSchool;
// assigning statementSchool value to s
var s = statementSchool;
// assigning whichSchool variable to w
var w = whichSchool;

// assign s, w, y to array all
var all = [s,w,y];

// using array in the simplest way
alert(all);

// making t a boolean value of true and f a value of false
var t = true;
var f = false;


// Assigning string to variable b
var b = "Is studying mobile technology a good idea?";
//using alert to display b
alert (b);

//using if and else with alerts I refrenced http://www.homeandlearn.co.uk/java/boolean_values.html
//this is the only way I know how to use boolean values
if (t = true) {
    alert(t);
}
else {
    alert(f);
}

console.log(s);
console.log(w);
console.log(y);
console.log(all);
console.log(t);
console.log(f);
